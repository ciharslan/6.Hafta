import React, { useState } from 'react';

function TemperatureConverter() {
  const [celsius, setCelsius] = useState('');
  const [fahrenheit, setFahrenheit] = useState('');
  const [kelvin, setKelvin] = useState('');

  const handleCelsiusChange = (e) => {
    const value = e.target.value;
    setCelsius(value);
    setFahrenheit(value !== '' ? ((value * 9) / 5 + 32).toFixed(2) : '');
    setKelvin(value !== '' ? (parseInt(value, 10) + 273.15).toFixed(2) : '');
  };

  const handleFahrenheitChange = (e) => {
    const value = e.target.value;
    setFahrenheit(value);
    setCelsius(value !== '' ? (((value - 32) * 5) / 9).toFixed(2) : '');
  };

  const handleKelvinChange = (e) => {
    const value = e.target.value;
    setKelvin(value);
    setCelsius(value !== '' ? (value - 273.15).toFixed(2) : '');
    setFahrenheit(value !== '' ? (((value - 273.15) * 9) / 5 + 32).toFixed(2) : '');
  };

  const inputStyle = {
    margin: '5px',
    padding: '8px',
    fontSize: '18px',
    backgroundColor: '#f0f0f0',
    border: '1px solid #ccc',
    borderRadius: '5px'
  };

  const containerStyle = {
    textAlign: 'center',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#e0e0e0',
    padding: '20px',
    borderRadius: '10px',
    width: '300px',
    margin: 'auto'
  };

  const labelStyle = {
    color: '#333',
    fontWeight: 'bold',
    marginRight: '10px'
  };

  return (
    <div style={containerStyle}>
      <h2>Temperature Converter</h2>
      <div>
        <label style={labelStyle}>Celsius: </label>
        <input type="number" value={celsius} onChange={handleCelsiusChange} style={inputStyle} />
      </div>
      <div>
        <label style={labelStyle}>Fahrenheit: </label>
        <input type="number" value={fahrenheit} onChange={handleFahrenheitChange} style={inputStyle} />
      </div>
      <div>
        <label style={labelStyle}>Kelvin: </label>
        <input type="number" value={kelvin} onChange={handleKelvinChange} style={inputStyle} />
      </div>
    </div>
  );
}

export default TemperatureConverter;